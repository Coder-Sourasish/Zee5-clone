var card = document.querySelector(".card");

card.addEventListener("click", function () {
    window.location.href = "playvideo.html";

});