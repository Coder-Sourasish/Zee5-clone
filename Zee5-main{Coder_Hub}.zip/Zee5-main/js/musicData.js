var musicData=[
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_223,h_125,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-2z564561/list/1170x658withlogo0da90666a77e4e7da39c1f49aec59b38.jpg",
        text:"Bhai Ka Birthday:Old Vs New Songs ",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599118/list/000000167717b9aae10d4a2f8d21397f0115f9be.jpg",
        text:"Hone Laga :Old Vs New Songs ",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_223,h_125,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-2z564570/list/1170x658withlogob3c55339732847949be96cb973253ee9.jpg",
        text:"Koi Toh Aayega:Old Vs New Songs ",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_382,h_215,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-manual_3ouhe1ql1u80/list/rebawree1170x658withlogo.jpg",
        text:"Re Bawree: New Vs Old Songs ",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_382,h_215,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-279563/list/1170x658withlog2057545688.jpg",
        text:"Behti Si Old Vs New Songs ",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_382,h_215,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-251744/list/1170x658withlog1522953698.jpg",
        text:"Kya Yeh Tumhe Pata Hai",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_382,h_215,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-manual_6b782evidnb0/list/bichhuabichookakhel.jpg",
        text:"Bichuaa Old Vs New Songs ",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_382,h_215,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-manual_3ouhe1ql1u80/list/rebawree1170x658withlogo.jpg",
        text:"Re Bawree Old Vs New Songs ",
    },

]

localStorage.setItem("music", JSON.stringify(musicData))