
# Clone of Zee5 Website

 I'm learning since Jan 26-2022. Now build a beautiful Zee5 Clone(Entertainment) website with help of Html,css,Js concept that teach in #unit-2 .

-->During this project, I faced many chanllenges likes- making responsive, but with help of our senior and google,bootsrap framework also help lots  to complete this website.


-->Following are the main technologies used in order to construct this frontend

. HTML
. CSS
. JavaScript


## Live Action 🌏

ZEE5 CLONE {netlify} :-https://legendary-dasik-96605c.netlify.app/
## Author ✍️

Mohammad Ahtisham
## Login page 👁️‍🗨️
![Screenshot (1876)](https://user-images.githubusercontent.com/100846744/167242467-1057b7f4-edb8-4f24-9ab4-07abf33b5c38.png)

## Home Page 🏠
![Screenshot (1875)](https://user-images.githubusercontent.com/100846744/167242457-6f74cb3b-267e-4c31-bbe4-7731fe27b608.png)

## Music Page 🎶
![Screenshot (1877)](https://user-images.githubusercontent.com/100846744/167242514-7403c00d-1eb6-47d0-8989-6b7feac29740.png)

## Footer Page 🚧
![Screenshot (1879)](https://user-images.githubusercontent.com/100846744/167242530-1901b2ed-c611-4520-b8ca-93e8052a6a13.png)






